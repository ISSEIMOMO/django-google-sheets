# django-google-sheets

essa biblioteca foi feito para uso proprio mas está sendo disponibilizado em varios projetos
devido a isso não existe uma documentação